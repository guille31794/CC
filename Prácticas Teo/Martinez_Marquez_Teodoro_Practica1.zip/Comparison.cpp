#include "ram.h"

void program()
{


  loop:           //Reach the first digit of second number.
  inc(1);         //i++
  load(2, 1);     //a = m[i];
  cgoto(2, loop); //while(a >= 0); (symbol $ is negative digit)

  inc(1);         //i++ (so it points towards first digit)
  reset(2);       //a becomes j, pointer to first number.
  inc(2);         //j++;

  loop2:          //while numbers keep matching
  load(3, 1);     //a = m[i]; digit of second number
  load(4, 2);     //b = m[j]; digit of first number
  cgoto(3, notEnd); //if a >= 0 goto notEnd, else goto equal
  cgoto(0, equal);
  notEnd:
  dec(3);         //a--, b-- so they're in range 0, -1
  dec(4);
  cgoto(3, fone); // if a == b == 0 goto correct, else goto uneq
  cgoto(4, uneq);
  cgoto(0, correct);
  fone:
  cgoto(4, correct);  //if a == b == 1 goto correct, else goto uneq
  cgoto(0, uneq);
  correct:
  inc(1); //i++, j++
  inc(2);
  cgoto(0, loop2);  //repeat process until out by end of digits or non-match.
  equal:
  reset(1);         //i will become output. i = 1.
  inc(1);
  cgoto(0, end);    //go to store output.
  uneq:
  reset(1);         //i will become output. i = 0.
  end:
  store(1, 0);
}


#include <iostream>
#include <iomanip>

memory r, m(1024);

int main()
{
  using namespace std;

  // Data input through the standard input.

  string s = "";
  cout << "Input string? ";
  getline(cin, s);

  // RAM initialization.

  initialize(5);		// Five registers.

  // RAM data input (memory initialization).

  for (string::size_type i = 0; i != s.size(); ++i)
    m[i + 1] = (int)(s[i]) - 48;
  m[s.size() + 1] = -1;

  // Program execution.

  program();

  // RAM data output (memory reading).

  integer l = m[0];

  // Data output through the standard output.

  cout << l << endl;
}
