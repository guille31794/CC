#include "ram.h"


void program()
{

  loop:
  inc(1);   //i++
  load(3,1);  //a = m[i];
  cgoto(4,halfInc); //if auxiliar == -1: l++, auxiliar++;
  inc(4);           //auxiliar = 0 & l++;
  inc(2);
  cgoto(4,next);
  halfInc:          //else auxiliar=-1;
  dec(4);
  next:
  cgoto(3,loop);
  
  dec(1);     //i--
  dec(2);     //l--
              //string length in r(1), half in r(2);
  reset(3);
  inc(3);   //start of string, j
  loop2:
  load(4, 1); //a = m[i]
  load(5, 3); //b = m[j]
  dec(4);
  dec(5);

  cgoto(4, fone);   //if a == 1 goto fone, else:
  cgoto(5, uneq);   //if b == 1 goto uneq
  cgoto(0, correct);//if a == b == 0 goto correct
  fone:
  cgoto(5, correct);//if a == b == 1 goto correct
  cgoto(0, uneq);   //else goto uneq
  correct:
  dec(1); //i--
  inc(3); //j++
  dec(2); //l--
  cgoto(2,loop2); //if l>=0 goto loop2 (repeat loop l times while digits match)
  reset(1); //i = 1
  inc(1);
  cgoto(0, end);
  uneq:
  reset(1); //i = 0 (if not palindrome)
  end:
  store(1, 0); //m[0] = i

}


#include <iostream>
#include <iomanip>

memory r, m(1024);

int main()
{
  using namespace std;

  // Data input through the standard input.

  string s = "";
  cout << "Input string? ";
  getline(cin, s);

  // RAM initialization.

  initialize(6);		// six registers.

  // RAM data input (memory initialization).

  for (string::size_type i = 0; i != s.size(); ++i)
    m[i + 1] = (int)(s[i]) - 48;
  m[s.size() + 1] = -1;

  // Program execution.

  program();

  // RAM data output (memory reading).

  integer l = m[0];

  // Data output through the standard output.

  cout << l << endl;
}
