#include "grafoP.h"
#include <iostream>
using namespace std;


int main(){
    //Inicializaci�n de grafo
    int NBase = 2;      //V�rtices obligatorios
    int Nvertices = 6;
    GrafoP G(Nvertices);

    for(int i = 0; i < Nvertices; ++i)
        for(int j = 0; j < Nvertices; ++j)
            G[i][j] = 20 - (i+j);

    for(int i = 0; i < 2; ++i)
        for(int j = 0; j < 2; ++j)
            G[i][j] = 90;

    for (int i = 0; i < Nvertices; ++i)
        G[i][i] = 0;

    GrafoP MejorGrafo = Treeparse(G, NBase);

    cout << "Terminado" << endl;

    return 0;
}
