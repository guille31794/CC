#include "grafoP.h"
#include <chrono>
#include <vector>
#include <iostream>
using namespace std;


int main(){

    int Nvertices = 30;   //Number of total vertices for the graph
    GrafoP G(Nvertices);  //Create graph with number of vertices
    for(int i = 0; i < Nvertices; ++i)  //Initialise values of the graph's cost matrix
    	for(int j = 0; j < Nvertices; ++j)
            G[i][j] = 2*Nvertices - (i+j);

    for (int i = 0; i < Nvertices; ++i) //Put the matrix' main diagonal at zero
        G[i][i] = 0;

    for(int NOpcionales = 0; NOpcionales <= 20; ++NOpcionales)
    {
      auto start = chrono::steady_clock::now(); //Starting time

      GrafoP MejorGrafo = Treeparse(G, Nvertices - NOpcionales);

      auto end = chrono::steady_clock::now();   //Ending time

      //Output the time taken by Treeparse depending on the number of optional nodes
      cout << NOpcionales << " ";
      cout << (float) chrono::duration_cast<chrono::microseconds>(end - start).count() / 1000000 << endl;
    }
    return 0;
}
