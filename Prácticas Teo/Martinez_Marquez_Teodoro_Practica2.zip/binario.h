#ifndef BINARIO
#define BINARIO
#include <vector>
using namespace std;
class Binario {     //Class to represent a binary number, to use for all node choice combinations.
public:
    int NOnes;      //Amount of ones in the number.
    Binario(int siz): NOnes(0), Bins(siz, 0){}
    void inc()      //Increment the binary number by one. Produces an error with overflows.
    {
        vector<int>::iterator it = Bins.begin();
        while(*it == 1 && it != Bins.end())
        {
            *it = 0;
            it++;
            NOnes--;
        }
        *it = 1;
        NOnes++;
    }
    int size() const{return Bins.size();}   //Return size of number

    int operator[](int indice){return Bins[indice];}
private:
    vector<int> Bins;   //Vector of ones and zeros.

};
#endif
