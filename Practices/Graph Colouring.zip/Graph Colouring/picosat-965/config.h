#define PICOSAT_CC "gcc"
#define PICOSAT_CFLAGS "-Wall -Wextra -DNDEBUG -O3"
#define PICOSAT_VERSION "965"
